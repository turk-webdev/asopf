Username for Server: cto
Login Type: SSH with no passphrase
Connecting to Server: ssh -i "[path/to/public/key]" cto@3.134.206.193
Closing Connection: exit
Webapp Location: /web-apps/public-safety-app/
